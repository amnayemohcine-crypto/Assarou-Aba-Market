Assarou Aba Market — Android APK Cloud Build

هذا المشروع مجهز باش يتبنى APK عبر GitHub Actions بدون PC.

الخطوات:
1) صايب Repository جديد فـ GitHub من الهاتف.
2) Upload لجميع الملفات والمجلدات الموجودة هنا.
3) دير Commit على main.
4) افتح Actions ثم Build APK ثم Run workflow.
5) منين يسالي البناء، افتح الـ workflow الناجح، ثم Artifacts، وحمل:
   Assarou-Aba-Market-APK
6) فك الضغط وغادي تلقى app-debug.apk.

ملاحظة:
- التطبيق مربوط بـ Supabase باستعمال Publishable Key.
- RLS الحالية اللي تدار فالمشروع كانت مفتوحة للتجربة؛ قبل الاستعمال التجاري الحقيقي خاصنا نزيدو Authentication وRLS آمنة.
- هذا APK تجريبي/نسخة أولى، وسنطورو بعد ذلك المبيعات، الفواتير، الديون، المشتريات، المصاريف والتقارير.
